//Question n0 1

const user = {
  name : 'John',
  Surname : 'Smith',

}
user.name = 'Pete';

console.log(user.name);
console.log(user);

delete user.name;
console.log (user);

//Question # 2
const obj= {}
console.log((obj));
//OR    // ISEMPTY 
if(!Object.keys(obj).length){
    console.log("object is empty");

}else console.log("object is not empty");

//Question # 3
let salaries ={
    John : 100,
    Ann : 160,
    Pete :130,

}
let sum = 0;
let salaries_arr= Object.values(salaries);
const sumValue = (salaries_arr) => {
    sum+=salaries_arr;
}
salaries_arr.forEach(sumValue)
console.log(sum);

//Question # 4
let menu = {
    width: 200,
    heigth: 300,
    title: "My menu"
};
 function multiplyNumeric(obj){
    for(let key in obj){
        if (typeof obj[key]=='number'){
            obj[key]*=2;
        }
    }
}
multiplyNumeric(menu);
console.log(menu);


//Question # 5 
const obj_1= {
num: 100,
sum: function (a, b){
    return a + b + this.num;
}
}
console.log(obj_1.sum(10,10));





//assignment 1

//let arr = ['Jazz', 'Blues']
//arr.push('Rock-n-Roll')
//console.log(arr);
//let replace = arr.splices(arr.length/(2,1,'classics'));
//console.log(arr);